package com.example.cw6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Movie titanic = new Movie("Titanic", "leanardo decaprio", 7.8, 86, "romantic");
        Movie enolaHolmes = new Movie("EnolaHolmes", "milliebobbybrown", 6.7, 80,"mystery");
        

    }
}