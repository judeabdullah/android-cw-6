package com.example.cw6;

public class Movie {
   private String title ;
   private String mainActor ;
   private double movierate ;
   private int pgRate ;
   private String genre ;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMainActor() {
        return mainActor;
    }

    public void setMainActor(String mainActor) {
        this.mainActor = mainActor;
    }

    public double getMovierate() {
        return movierate;
    }

    public void setMovierate(double movierate) {
        this.movierate = movierate;
    }

    public int getPgRate() {
        return pgRate;
    }

    public void setPgRate(int pgRate) {
        this.pgRate = pgRate;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Movie(String title, String mainActor, double movierate, int pgRate, String genre) {
        this.title = title;
        this.mainActor = mainActor;
        this.movierate = movierate;
        this.pgRate = pgRate;
        this.genre = genre;
    }
}
