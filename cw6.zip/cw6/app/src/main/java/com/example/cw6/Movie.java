package com.example.cw6;

public class Movie {
    String title ;
    String mainActor ;
    double movierate ;
    int pgRate ;
    String genre ;
    
}
